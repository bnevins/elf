//#ifndef DATA_INCLUDED
//#define DATA_INCLUDED

static const int NUM_VALVES = 3;
static const int FIRST_VALVE = 7;
static const int DELAY = 500;

// momentary NO switch.  Listen as a ISR
static const int INTERRUPT_PIN = 2;
static const int INTERRUPT_NUM = 0;
static const int SHORT_TIME = 5;
static const int MEDIUM_TIME = 30;
static const int LONG_TIME = 60;
static int  currentValve = -1;
static const int DEBUG = 1;
//#endif
